import React, { useState, useEffect } from "react";
import { authService, decodeErrorResponse } from "../../../services/api";
import { Link, useNavigate } from "react-router-dom";
import { CsrfLoadingProps } from "../../../types";

// Tipe data yang lebih lengkap sesuai form Blade
interface RegisterFormData {
  full_name: string;
  email: string;
  phone: string;
  nip: string;
  password: string;
  password_confirmation: string;
  role: "system_admin" | "base_admin" | "";
  service_code: string | null;
  kta_scan: File | null;
}

// Tipe data untuk opsi filter (diasumsikan didapat dari API)
interface RegisterOptions {
  roles: string[];
  serviceProfiles: { code: string; full_name: string }[];
}

export default function RegisterPage({ csrfLoading }: CsrfLoadingProps) {
  const [formData, setFormData] = useState<RegisterFormData>({
    full_name: "",
    email: "",
    phone: "",
    nip: "",
    password: "",
    password_confirmation: "",
    role: "",
    service_code: "",
    kta_scan: null,
  });

  const [options, setOptions] = useState<RegisterOptions>({
    roles: [],
    serviceProfiles: [],
  });
  const [error, setError] = useState<string | string[] | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  // Efek untuk mengambil data dropdown (roles & services) saat komponen dimuat
  useEffect(() => {
    const fetchOptions = async () => {
      try {
        // Asumsi ada endpoint API untuk mendapatkan data ini
        const response = await authService.getRegisterOptions();
        console.log({ responseData: response.data });
        setOptions(response.data);
      } catch (err) {
        setError("Gagal memuat opsi pendaftaran.");
      }
    };
    if (csrfLoading) {
      fetchOptions();
    }
  }, [csrfLoading]);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFormData((prev) => ({ ...prev, kta_scan: e.target.files![0] }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);

    if (formData.password !== formData.password_confirmation) {
      setError("Kata sandi tidak cocok!");
      return;
    }

    const data = new FormData();

    data.append("full_name", formData.full_name);
    data.append("email", formData.email);
    data.append("phone", formData.phone);
    data.append("password", formData.password);
    data.append("nip", formData.nip);
    data.append("role", formData.role);
    data.append("service_code", formData.service_code as string);
    data.append("kta_scan", formData.kta_scan as File);

    try {
      const response = await authService.registerStart(data);
      const stateData = {
        ...formData,
        service_code: formData.service_code || null,
        kta_scan_path: response.data.kta_scan_path,
      };
      setSuccess(
        response.data.message ||
          "Data berhasil dikirim. Silakan verifikasi OTP."
      );
      navigate("/register/verify-otp", { state: stateData });
    } catch (err: any) {
      const decodedError = await decodeErrorResponse(err);
      setError(decodedError || "Terjadi kesalahan saat mengirim data.");
    } finally {
      setLoading(false);
    }
  };

  // Definisikan class CSS untuk konsistensi
  const inputClass =
    "mt-1 block w-full border-gray-300 rounded-md shadow-sm p-2 border outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm";
  const fileInputClass =
    "mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100";
  const buttonClass =
    "w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50";

  return (
    <div className="max-w-lg mx-auto bg-white shadow-lg rounded-xl p-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center">
        Halaman Registrasi
      </h1>
      <p className="text-gray-600 mb-8 text-center">
        Silakan lengkapi data di bawah ini untuk mendaftar:
      </p>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label
            htmlFor="full_name"
            className="block text-sm font-medium text-gray-700"
          >
            Nama Lengkap
          </label>
          <input
            type="text"
            id="full_name"
            name="full_name"
            value={formData.full_name}
            onChange={handleChange}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700"
          >
            Alamat Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label
            htmlFor="phone"
            className="block text-sm font-medium text-gray-700"
          >
            Nomor Telepon
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label
            htmlFor="nip"
            className="block text-sm font-medium text-gray-700"
          >
            NIP
          </label>
          <input
            type="text"
            id="nip"
            name="nip"
            value={formData.nip}
            onChange={handleChange}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label
            htmlFor="password"
            className="block text-sm font-medium text-gray-700"
          >
            Password
          </label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
            className={inputClass}
          />
        </div>
        <div>
          <label
            htmlFor="password_confirmation"
            className="block text-sm font-medium text-gray-700"
          >
            Konfirmasi Password
          </label>
          <input
            type="password"
            id="password_confirmation"
            name="password_confirmation"
            value={formData.password_confirmation}
            onChange={handleChange}
            required
            className={inputClass}
          />
        </div>

        <div>
          <label
            htmlFor="role"
            className="block text-sm font-medium text-gray-700"
          >
            Peran (Role)
          </label>
          <select
            name="role"
            id="role"
            value={formData.role}
            onChange={handleChange}
            required
            className={inputClass}
          >
            <option value="">Pilih Peran</option>
            {/* DIPERBAIKI: Mapping disesuaikan dengan struktur objek { name, value } */}
            {options.roles.map((role) => (
              <option key={role} value={role}>
                {role
                  .split("_")
                  .map((c) => c[0].toUpperCase() + c.substring(1))
                  .join(" ")}
              </option>
            ))}
          </select>
        </div>

        {formData.role === "base_admin" && (
          <div>
            <label
              htmlFor="service_code"
              className="block text-sm font-medium text-gray-700"
            >
              Asal Dinas
            </label>
            <select
              name="service_code"
              id="service_code"
              value={formData.service_code || ""}
              onChange={handleChange}
              required
              className={inputClass}
            >
              <option value="">Pilih Asal Dinas</option>
              {options.serviceProfiles.map((profile) => (
                <option key={profile.code} value={profile.code}>
                  {profile.full_name}
                </option>
              ))}
            </select>
          </div>
        )}

        <div>
          <label
            htmlFor="kta_scan"
            className="block text-sm font-medium text-gray-700"
          >
            Scan KTA/Kartu Pegawai
          </label>
          <input
            type="file"
            id="kta_scan"
            name="kta_scan"
            onChange={handleFileChange}
            required
            className={fileInputClass}
          />
        </div>

        <div className="pt-4">
          <button type="submit" disabled={loading} className={buttonClass}>
            {loading ? "Mengirim..." : "Daftar & Kirim Kode Verifikasi"}
          </button>
        </div>
      </form>

      {!success && (
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Sudah punya akun?
            <Link
              to="/login"
              className="font-medium text-blue-600 hover:text-blue-500 ml-1"
            >
              Login di sini
            </Link>
          </p>
        </div>
      )}
    </div>
  );
}
